
#include "cctk.h"

CCTK_INT ADMDerivatives_GetGridRanges(cGH *cctkGH, int* istart,
                                      int* iend);
