#include <cstdio>
#include <cassert>
#include <vector>
#include <ios>

#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>
#include <algorithm>

#define MAX(a,b) ( ((a) > (b)) ? (a) : (b) )
#define MIN(a,b) ( ((a) < (b)) ? (a) : (b) )

extern "C"
void Seed_Magnetic_Fields_BNS (CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_Seed_Magnetic_Fields_BNS;
  DECLARE_CCTK_PARAMETERS;

  CCTK_INFO ("Seeding magnetic fields");

  CCTK_REAL dX = CCTK_DELTA_SPACE(0);
  CCTK_REAL dY = CCTK_DELTA_SPACE(1);

  if(enable_IllinoisGRMHD_staggered_A_fields) {
#pragma omp parallel for
    for(int k=0; k<cctk_lsh[2]; k++) {
      for(int j=0; j<cctk_lsh[1]; j++) {
        for(int i=0; i<cctk_lsh[0]; i++) {
          const int ip1 = MIN(i+1,cctk_lsh[0]-1);
          const int jp1 = MIN(j+1,cctk_lsh[1]-1);
          const int kp1 = MIN(k+1,cctk_lsh[2]-1);

          const int index = CCTK_GFINDEX3D(cctkGH, i, j ,k);
          const int indexip1    = CCTK_GFINDEX3D(cctkGH, ip1, j,   k);
          const int indexjp1    = CCTK_GFINDEX3D(cctkGH, i,   jp1, k);
          const int indexkp1    = CCTK_GFINDEX3D(cctkGH, i,   j,   kp1);
          const int indexip1kp1 = CCTK_GFINDEX3D(cctkGH, ip1, j,   kp1);
          const int indexjp1kp1 = CCTK_GFINDEX3D(cctkGH, i,   jp1, kp1);

          const CCTK_REAL xL = x[index];
          const CCTK_REAL yL = y[index];
          const CCTK_REAL zL = z[index];
          const CCTK_REAL x1 = xL - x_c1;
          const CCTK_REAL x2 = xL - x_c2;

          const CCTK_REAL r1 = sqrt(x1*x1 + yL*yL + zL*zL);
          const CCTK_REAL r2 = sqrt(x2*x2 + yL*yL + zL*zL);

          if(CCTK_EQUALS(Afield_type, "BNS_poloidal_A_interior")) {
            const CCTK_REAL PL = press[index]; // Assumes HydroBase pressure is set!

            const CCTK_REAL PLip1 = press[indexip1];
            const CCTK_REAL PLjp1 = press[indexjp1];
            const CCTK_REAL PLkp1 = press[indexkp1];
            const CCTK_REAL PLip1kp1 = press[indexip1kp1];
            const CCTK_REAL PLjp1kp1 = press[indexjp1kp1];
          
            const CCTK_REAL Pressure_at_Ax_stagger = 0.25*(PL + PLjp1 + PLkp1 + PLjp1kp1);
            Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,0)] = -(yL + 0.5*dY)*A_b*pow(MAX(Pressure_at_Ax_stagger-P_cut,0.0),n_s);

            const CCTK_REAL Pressure_at_Ay_stagger = 0.25*(PL + PLip1 + PLkp1 + PLip1kp1);

            if(!have_two_NSs_along_x_axis) Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] =  (xL + 0.5*dX)*A_b*pow(MAX(Pressure_at_Ay_stagger-P_cut,0.0),n_s);
            else {
              if(r1<=r_NS1) Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] =  (x1 + 0.5*dX)*A_b*pow(MAX(Pressure_at_Ay_stagger-P_cut,0.0),n_s);
              if(r2<=r_NS2) Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] =  (x2 + 0.5*dX)*A_b*pow(MAX(Pressure_at_Ay_stagger-P_cut,0.0),n_s);
              if(r1>r_NS1 && r2>r_NS2) Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] = 0.0; // No external B-field.
            }
          // Modified to include poloidal vector potential option
          } else if(CCTK_EQUALS(Afield_type, "BNS_dipolar_A_everywhere")) {
            const CCTK_REAL pi = 3.141592653589793;

            // \varpi^2
            const CCTK_REAL varpi1_2 = x1 * x1 + yL * yL;
            const CCTK_REAL varpi2_2 = x2 * x2 + yL * yL;

            // Current loop radius
            const CCTK_REAL r01 = r_zero_NS1 * r_NS1;
            const CCTK_REAL r02 = r_zero_NS2 * r_NS2;

            // phi-component of vector potential in spherical basis
            // Eq (2) in Paschalidis et al PRD 88 021504(R) (2013)
            const CCTK_REAL Ap1 = pi * r01 * r01 * I_zero_NS1 * pow(r01 * r01 + r1 * r1, -1.5) * (1.0 + 1.875 * r01 * r01 * (r01 * r01 + varpi1_2) * pow(r01 * r01 + r1 * r1, -2.0));
            const CCTK_REAL Ap2 = pi * r02 * r02 * I_zero_NS2 * pow(r02 * r02 + r2 * r2, -1.5) * (1.0 + 1.875 * r02 * r02 * (r02 * r02 + varpi2_2) * pow(r02 * r02 + r2 * r2, -2.0));

            // x-component of vector potential in Cartesian basis
            Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,0)] = - (yL + 0.5 * dY) * (Ap1 + Ap2);

            // y-component of vector potential in Cartesian basis
            Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] = (x1 + 0.5 * dX) * Ap1 + (x2 + 0.5 * dX) * Ap2;
          }

          // z-component of vector potential in Cartesian basis
          Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,2)] =  0.0;
          Aphi[index]  = 0.0;
        }
      }
    }
  } else {
#pragma omp parallel for
    for(int k=0; k<cctk_lsh[2]; k++) {
      for(int j=0; j<cctk_lsh[1]; j++) {
        for(int i=0; i<cctk_lsh[0]; i++) {
          const int index=CCTK_GFINDEX3D(cctkGH,i,j,k);

          const CCTK_REAL PL = press[index]; // Assumes HydroBase pressure is set!

          Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,0)] = -y[index]*A_b*pow(MAX(PL-P_cut,0.0),n_s);
          Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,1)] =  x[index]*A_b*pow(MAX(PL-P_cut,0.0),n_s);
          Avec[CCTK_VECTGFINDEX3D(cctkGH,i,j,k,2)] =  0.0;
          Aphi[index]  = 0.0;
        }
      }
    }
  }
}
