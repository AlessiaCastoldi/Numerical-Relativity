/*@@
  @header   DCGDT_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DCGDT_GUTS

#include "LIEG_undefine.h"


