/*@@
  @header   DXYDG_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DXYDG_GUTS

#include "DXDG_undefine.h"
#include "DYDG_undefine.h"

