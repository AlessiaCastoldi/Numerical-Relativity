/*@@
  @header   CHR1_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CHR1_GUTS

#include "DG_undefine.h"


