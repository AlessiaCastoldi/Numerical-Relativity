/*@@
  @header   MOMYADM_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef MOMYADM_GUTS

#include "UPPERMET_undefine.h"
#include "CDK_undefine.h"





