rfm_struct rfmstruct;
