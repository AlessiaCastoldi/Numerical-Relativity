COEFF(0,0,0) = factor * coeffs->coeff_0_0_0;
COEFF(1,0,0) = factor * coeffs->coeff_p1_0_0;
COEFF(0,1,0) = factor * coeffs->coeff_0_p1_0;
COEFF(1,1,0) = factor * coeffs->coeff_p1_p1_0;
COEFF(0,0,1) = factor * coeffs->coeff_0_0_p1;
COEFF(1,0,1) = factor * coeffs->coeff_p1_0_p1;
COEFF(0,1,1) = factor * coeffs->coeff_0_p1_p1;
COEFF(1,1,1) = factor * coeffs->coeff_p1_p1_p1;
