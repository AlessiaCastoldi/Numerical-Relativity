#ifndef OPERATOR_PROTOTYPES
#define OPERATOR_PROTOTYPES

namespace CarpetLib {

static int const reffact2 = 2;

} // namespace CarpetLib

#endif // #ifndef OPERATOR_PROTOTYPES
