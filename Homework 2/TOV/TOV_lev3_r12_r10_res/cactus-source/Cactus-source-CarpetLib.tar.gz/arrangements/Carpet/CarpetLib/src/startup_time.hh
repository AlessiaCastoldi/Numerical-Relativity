#ifndef STARTUP_TIME_HH
#define STARTUP_TIME_HH

namespace CarpetLib {

void output_startup_time();

} // namespace CarpetLib

#endif // #ifndef STARTUP_TIME_HH
