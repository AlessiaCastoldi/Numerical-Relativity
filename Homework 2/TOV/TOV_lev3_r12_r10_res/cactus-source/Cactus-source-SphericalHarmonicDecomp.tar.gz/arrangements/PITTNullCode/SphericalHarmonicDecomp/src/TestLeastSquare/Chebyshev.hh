#ifndef DECOMP_CHEBYSHEV_HH
#define DECOMP_CHEBYSHEV_HH
namespace decomp_Chebyshev
{
  double ChebyshevU(int n, double x);
}
#endif
