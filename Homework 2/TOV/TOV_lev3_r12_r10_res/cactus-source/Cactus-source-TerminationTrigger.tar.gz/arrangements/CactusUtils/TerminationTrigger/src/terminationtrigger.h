#ifndef TERMINATION_TRIGGER_H_
#define TERMINATION_TRIGGER_H_

#include "cctk.h"
void TerminationTrigger_TriggerTermination(CCTK_ARGUMENTS);

#endif // TERMINATION_TRIGGER_H_
