#define	WSOLVE
#include "umfpack_solve.c"
