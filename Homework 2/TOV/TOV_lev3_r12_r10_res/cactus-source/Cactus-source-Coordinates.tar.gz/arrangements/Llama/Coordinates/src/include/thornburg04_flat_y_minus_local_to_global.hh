
/* Copyright 2013 Peter Diener, Nils Dorband, Roland Haas, Ian Hinder,
Christian Ott, Denis Pollney, Thomas Radke, Christian Reisswig, Erik
Schnetter, Barry Wardell and Burkhard Zink

This file is part of Llama.

Llama is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation, either version 2 of the License, or (at your
option) any later version.

Llama is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with Llama.  If not, see <http://www.gnu.org/licenses/>. */

// This file has been generated automatically.  Do not change it manually.
R=sqrt(pow(ri-rm,-3.)*(rm*(ri*ri)*(-2.*(rm*rm)-rm*rm*(xp*xp)-rm*rm*(yp*yp)+r\
i*rm*(2.+xp*xp+yp*yp)+2.*sqrt(rm*rm*(1.+xp*xp+yp*yp)*pow(ri-rm,2.)))-2.*ri*\
zp*(rm*(ri*ri)+rm*(ri*ri)*(xp*xp)-ri*(rm*rm)*(xp*xp)+rm*(ri*ri)*(yp*yp)-ri*\
(rm*rm)*(yp*yp)-pow(rm,3.)+ri*sqrt(rm*rm*(1.+xp*xp+yp*yp)*pow(ri-rm,2.))+rm\
*sqrt(rm*rm*(1.+xp*xp+yp*yp)*pow(ri-rm,2.)))+zp*zp*(-(rm*(ri*ri)*(1.+xp*xp+\
yp*yp))+(1.+xp*xp+yp*yp)*pow(ri,3.)-pow(rm,3.)+ri*(rm*rm+2.*sqrt(rm*rm*(1.+\
xp*xp+yp*yp)*pow(ri-rm,2.))))));
